$(function(){
    // 开始写 jQuery 代码...
    //$(selector).action()
/**/



});

