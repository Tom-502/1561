$(function(){

    // 开始写 jQuery 代码...
    //$(selector).action()

    $(".publish-icon").click(function(){
        window.location.replace("../3/3.html.html")
    });
    $(".check-icon").click(function(){
        window.location.replace("../2/作业查看.html.html")
    });


});